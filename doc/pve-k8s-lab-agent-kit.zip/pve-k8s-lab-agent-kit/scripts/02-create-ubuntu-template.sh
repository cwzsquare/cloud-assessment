#!/usr/bin/env bash
set -euo pipefail
source /root/cnsec-lab/lab.env
IMG="/var/lib/vz/template/iso/ubuntu-24.04-server-cloudimg-amd64.img"

if [ ! -s "${SSH_PUBKEY_PATH}" ]; then
  echo "ERROR: 缺少 SSH public key: ${SSH_PUBKEY_PATH}" >&2
  exit 20
fi

wget -nc -O "$IMG" "$UBUNTU_CLOUD_IMAGE"

if qm status "$UBUNTU_TEMPLATE_ID" >/dev/null 2>&1; then
  echo "Template VM ${UBUNTU_TEMPLATE_ID} already exists, skip."
  exit 0
fi

qm create "$UBUNTU_TEMPLATE_ID" \
  --name ubuntu-2404-k8s-template \
  --memory 2048 \
  --cores 2 \
  --cpu host \
  --net0 virtio,bridge="$PVE_LAB_BRIDGE" \
  --ostype l26 \
  --agent enabled=1 \
  --scsihw virtio-scsi-single \
  --serial0 socket \
  --vga serial0

qm importdisk "$UBUNTU_TEMPLATE_ID" "$IMG" "$PVE_STORAGE"
qm set "$UBUNTU_TEMPLATE_ID" --scsi0 "${PVE_STORAGE}:vm-${UBUNTU_TEMPLATE_ID}-disk-0"
qm set "$UBUNTU_TEMPLATE_ID" --ide2 "${PVE_STORAGE}:cloudinit"
qm set "$UBUNTU_TEMPLATE_ID" --boot order=scsi0
qm set "$UBUNTU_TEMPLATE_ID" --ciuser agent --sshkeys "$SSH_PUBKEY_PATH"
qm set "$UBUNTU_TEMPLATE_ID" --ipconfig0 ip=dhcp
qm resize "$UBUNTU_TEMPLATE_ID" scsi0 +18G
qm template "$UBUNTU_TEMPLATE_ID"
