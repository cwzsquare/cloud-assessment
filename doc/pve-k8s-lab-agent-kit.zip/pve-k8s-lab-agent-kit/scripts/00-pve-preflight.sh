#!/usr/bin/env bash
set -euo pipefail
source /root/cnsec-lab/lab.env
OUT=/root/cnsec-lab/preflight.txt
{
  echo "## PVE version"
  pveversion -v || true
  echo
  echo "## CPU virtualization flags"
  egrep -m 5 -o 'vmx|svm' /proc/cpuinfo || true
  echo
  echo "## KVM modules"
  lsmod | grep -E '^kvm|kvm_intel|kvm_amd' || true
  echo
  echo "## Nested parameter"
  cat /sys/module/kvm_intel/parameters/nested 2>/dev/null || true
  cat /sys/module/kvm_amd/parameters/nested 2>/dev/null || true
  echo
  echo "## Storage"
  pvesm status || true
  echo
  echo "## Network"
  ip -br addr || true
  echo
  echo "## Existing VMs/CTs"
  qm list || true
  pct list || true
} | tee "$OUT"

if ! egrep -q 'vmx|svm' /proc/cpuinfo; then
  echo "ERROR: 当前 PVE nested host 看不到 vmx/svm。请先在外层虚拟化平台开启 nested virtualization / expose hardware virtualization。" >&2
  exit 10
fi
