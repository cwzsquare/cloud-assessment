#!/usr/bin/env bash
set -euo pipefail
source /root/cnsec-lab/lab.env

ssh agent@"$CP1_IP" "sudo hostnamectl set-hostname $CP1_NAME"
ssh agent@"$W1_IP"  "sudo hostnamectl set-hostname $W1_NAME"
ssh agent@"$W2_IP"  "sudo hostnamectl set-hostname $W2_NAME"
for ip in "$CP1_IP" "$W1_IP" "$W2_IP"; do
  ssh agent@"$ip" "cat <<EOF2 | sudo tee -a /etc/hosts
${CP1_IP} ${CP1_NAME}
${W1_IP} ${W1_NAME}
${W2_IP} ${W2_NAME}
EOF2"
done

ssh agent@"$CP1_IP" "sudo kubeadm init \
  --apiserver-advertise-address=${CP1_IP} \
  --control-plane-endpoint=${CP1_IP} \
  --pod-network-cidr=${POD_CIDR} \
  --service-cidr=${SERVICE_CIDR} \
  --kubernetes-version=${K8S_VERSION} \
  --upload-certs"

ssh agent@"$CP1_IP" 'mkdir -p $HOME/.kube && sudo cp /etc/kubernetes/admin.conf $HOME/.kube/config && sudo chown $(id -u):$(id -g) $HOME/.kube/config'
scp agent@"$CP1_IP":/home/agent/.kube/config /root/cnsec-lab/kubeconfig

JOIN_CMD=$(ssh agent@"$CP1_IP" 'sudo kubeadm token create --print-join-command')
echo "sudo ${JOIN_CMD}" >/root/cnsec-lab/join-command.sh
chmod +x /root/cnsec-lab/join-command.sh
for ip in "$W1_IP" "$W2_IP"; do
  ssh agent@"$ip" "sudo ${JOIN_CMD}"
done
