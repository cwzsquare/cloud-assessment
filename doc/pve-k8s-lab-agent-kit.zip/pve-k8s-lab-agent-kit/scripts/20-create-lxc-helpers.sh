#!/usr/bin/env bash
set -euo pipefail
source /root/cnsec-lab/lab.env

pveam update
TEMPLATE=$(pveam available --section system | awk '/debian-12-standard/ {print $2; exit}')
if [ -z "$TEMPLATE" ]; then
  echo "ERROR: 找不到 debian-12-standard LXC template" >&2
  exit 30
fi
pveam download local "$TEMPLATE" || true

create_ct() {
  local id="$1" host="$2" ip="$3" mem="$4"
  if pct status "$id" >/dev/null 2>&1; then
    echo "CT $id exists, skip."
  else
    pct create "$id" "local:vztmpl/${TEMPLATE}" \
      --hostname "$host" \
      --cores 2 \
      --memory "$mem" \
      --swap 512 \
      --rootfs "${PVE_STORAGE}:20" \
      --net0 name=eth0,bridge="$PVE_LAB_BRIDGE",ip="${ip}/24",gw="$PVE_LAB_GW" \
      --features nesting=1,keyctl=1 \
      --unprivileged 1 \
      --ssh-public-keys "$SSH_PUBKEY_PATH"
  fi
  pct start "$id" || true
}

create_ct "$REGISTRY_CT_ID" registry-lab "$REGISTRY_IP" 2048
create_ct "$NFS_CT_ID"      nfs-lab      "$NFS_IP"      1024
create_ct "$LOG_CT_ID"      log-sink     "$LOG_IP"      1024

pct exec "$LOG_CT_ID" -- bash -lc 'apt-get update && apt-get install -y python3 && mkdir -p /srv/cnsec-logs'
pct exec "$NFS_CT_ID" -- bash -lc 'apt-get update && apt-get install -y nfs-kernel-server && mkdir -p /srv/nfs/cnsec && chmod 777 /srv/nfs/cnsec && echo "/srv/nfs/cnsec *(rw,sync,no_subtree_check,no_root_squash)" >/etc/exports && exportfs -ra && systemctl enable --now nfs-server || true'
pct exec "$REGISTRY_CT_ID" -- bash -lc 'apt-get update && apt-get install -y docker.io || true'
pct exec "$REGISTRY_CT_ID" -- bash -lc 'docker run -d --restart=always --name registry -p 5000:5000 registry:2 || (mkdir -p /srv/registry-mock && cd /srv/registry-mock && nohup python3 -m http.server 5000 >/tmp/registry-mock.log 2>&1 &)'

pct list
