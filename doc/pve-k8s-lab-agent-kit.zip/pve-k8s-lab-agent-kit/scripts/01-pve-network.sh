#!/usr/bin/env bash
set -euo pipefail
source /root/cnsec-lab/lab.env
cp /etc/network/interfaces "/etc/network/interfaces.$(date +%Y%m%d%H%M%S).bak"

if ! grep -q "iface ${PVE_LAB_BRIDGE} inet static" /etc/network/interfaces; then
cat >>/etc/network/interfaces <<EOF2

auto ${PVE_LAB_BRIDGE}
iface ${PVE_LAB_BRIDGE} inet static
    address ${PVE_LAB_GW}/24
    bridge-ports none
    bridge-stp off
    bridge-fd 0
EOF2
fi

if command -v ifreload >/dev/null 2>&1; then
  ifreload -a
else
  systemctl restart networking
fi

cat >/etc/sysctl.d/99-cnsec-lab.conf <<EOF2
net.ipv4.ip_forward=1
net.bridge.bridge-nf-call-iptables=1
net.bridge.bridge-nf-call-ip6tables=1
EOF2
sysctl --system

iptables -t nat -C POSTROUTING -s "${PVE_LAB_CIDR}" -o "${PVE_NAT_OUT_IF}" -j MASQUERADE 2>/dev/null \
  || iptables -t nat -A POSTROUTING -s "${PVE_LAB_CIDR}" -o "${PVE_NAT_OUT_IF}" -j MASQUERADE
iptables -C FORWARD -i "${PVE_LAB_BRIDGE}" -o "${PVE_NAT_OUT_IF}" -j ACCEPT 2>/dev/null \
  || iptables -A FORWARD -i "${PVE_LAB_BRIDGE}" -o "${PVE_NAT_OUT_IF}" -j ACCEPT
iptables -C FORWARD -i "${PVE_NAT_OUT_IF}" -o "${PVE_LAB_BRIDGE}" -m state --state RELATED,ESTABLISHED -j ACCEPT 2>/dev/null \
  || iptables -A FORWARD -i "${PVE_NAT_OUT_IF}" -o "${PVE_LAB_BRIDGE}" -m state --state RELATED,ESTABLISHED -j ACCEPT

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y iptables-persistent curl jq git wget unzip || true
netfilter-persistent save || true
ip -br addr show "${PVE_LAB_BRIDGE}"
