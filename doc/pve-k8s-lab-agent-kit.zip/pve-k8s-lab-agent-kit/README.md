# PVE/K8s Lab Agent Kit

This bundle contains skeleton scripts and manifests for building a nested Proxmox VE Kubernetes lab used as the target environment for the cloud-native security assessment prototype.

Usage on the PVE host:

```bash
mkdir -p /root/cnsec-lab
cp lab.env.example /root/cnsec-lab/lab.env
cp -r scripts manifests logs /root/cnsec-lab/
vi /root/cnsec-lab/lab.env
chmod +x /root/cnsec-lab/scripts/*.sh
/root/cnsec-lab/scripts/00-pve-preflight.sh
/root/cnsec-lab/scripts/01-pve-network.sh
/root/cnsec-lab/scripts/02-create-ubuntu-template.sh
/root/cnsec-lab/scripts/03-create-k8s-vms.sh
```

Then wait for cloud-init, run the node common installer on each VM, initialize Kubernetes, install addons, and apply manifests as described in the engineering document section 14.

Do not run these scripts on a production PVE host. They intentionally create insecure demo workloads under `cnsec-bad`.
